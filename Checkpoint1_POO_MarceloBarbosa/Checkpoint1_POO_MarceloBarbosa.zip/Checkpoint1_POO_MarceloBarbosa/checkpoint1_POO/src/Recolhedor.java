import java.util.Arrays;

public class Recolhedor extends Usuario {

    private String cpf;

    private Veiculo[] veiculo;

    public Recolhedor(){};

    public Recolhedor(int id, String nome, String email, String telefone, String cpf) {
        super(id, nome, email, telefone);
        this.cpf = cpf;

    }

    public void qtdVeiculos(int qtd){
        this.veiculo = new Veiculo[qtd];
    }

    public void cadastrarVeiculo(int id, String placa, String marca, String modelo){
        this.veiculo[id] = new Veiculo(placa, marca, modelo);
    }

    public void imprimirVeiculos(){
        for (int i = 0; i < this.veiculo.length; ++i) {
           System.out.println(this.veiculo[i].getPlaca() + " " + this.veiculo[i].getModelo() + " " + this.veiculo[i].getMarca());
        }
    }

    public Veiculo selecionarVeiculo(int id){
        return this.veiculo[id];
    }

    public String getCpf() {
        return cpf;
    }

    public void setCpf(String cpf) {
        this.cpf = cpf;
    }

    public Veiculo[] getVeiculo() {
        return veiculo;
    }

    public void setVeiculo(Veiculo[] veiculo) {
        this.veiculo = veiculo;
    }
}
