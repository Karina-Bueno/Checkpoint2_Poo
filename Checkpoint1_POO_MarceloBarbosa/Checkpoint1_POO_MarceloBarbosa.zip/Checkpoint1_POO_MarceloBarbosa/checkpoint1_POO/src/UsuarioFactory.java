public class UsuarioFactory {
    private static UsuarioFactory instance;
    private UsuarioFactory(){};
    public static UsuarioFactory getInstance(){
        if(instance == null){
            instance = new UsuarioFactory();
        }
        return instance;
    }
    public Usuario criarUsuario (String tipo,int id, String nome, String email, String telefone,String cpf_cnpj){
        if (tipo.equals("D")){
            Residente residente = new Residente();
            residente.setId(id);
            residente.setNome(nome);
            residente.setEmail(email);
            residente.setTelefone(telefone);
            residente.setCpf(cpf_cnpj);
            return residente;
        }
        else if  (tipo.equals("R")){
            Recolhedor recolhedor = new Recolhedor();
            recolhedor.setId(id);
            recolhedor.setNome(nome);
            recolhedor.setEmail(email);
            recolhedor.setTelefone(telefone);
            recolhedor.setCpf(cpf_cnpj);
            return recolhedor;
        }
        else if(tipo.equals("O")){
            Organizacao organizacao = new Organizacao();
            organizacao.setId(id);
            organizacao.setNome(nome);
            organizacao.setEmail(email);
            organizacao.setTelefone(telefone);
            organizacao.setCnpj(cpf_cnpj);
            return organizacao;
        }
        return null;
    }
}
