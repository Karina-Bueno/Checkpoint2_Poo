import java.util.ArrayList;

public class Agendamento {

    private Recolhedor recolhedor;
    private Residente residente;
    private Organizacao organizacao;

    private int id;
    //criar uma array pro material
    private ArrayList<Material> listaMaterial = new ArrayList<>();
    private Veiculo veiculo;

    public ArrayList<Material> getListaMaterial() {
        return listaMaterial;
    }

    public void setListaMaterial(ArrayList<Material> listaMaterial) {
        this.listaMaterial = listaMaterial;
    }

    public void imprimirRecibo(){
        System.out.println("Recibo de Busca");
        System.out.println("Buscar Material de : " + this.residente.getNome());
        this.residente.imprimirEndereco();
        System.out.println("Recolhedor: " + this.recolhedor.getNome());
        System.out.println("Empresa Entrega: " + this.organizacao.getNome());
        this.organizacao.imprimirEndereco();
        System.out.println("Valor total a pagar: R$ " + calcularTotal());
    }
    public void addMaterias(Material material){
        listaMaterial.add(material);
    };

    private double calcularTotal(){
        double soma=0.0;
        for (Material m:listaMaterial){
            soma+=m.calculaPreco();
        }
        return soma;
    };


    public void escolhaVeiculo(Veiculo veiculo){
        this.veiculo = veiculo;
    }

    public Agendamento(int id, Residente residente, Recolhedor recolhedor, Organizacao organizacao) {
        this.id = id;
        this.residente = residente;
        this.recolhedor = recolhedor;
        this.organizacao = organizacao;
    }

    public Veiculo getVeiculo() {
        return veiculo;
    }

    public void setVeiculo(Veiculo veiculo) {
        this.veiculo = veiculo;
    }
    public Recolhedor getRecolhedor() {
        return recolhedor;
    }

    public void setRecolhedor(Recolhedor recolhedor) {
        this.recolhedor = recolhedor;
    }

    public Residente getResidente() {
        return residente;
    }

    public void setResidente(Residente residente) {
        this.residente = residente;
    }

    public Organizacao getOrganizacao() {
        return organizacao;
    }

    public void setOrganizacao(Organizacao organizacao) {
        this.organizacao = organizacao;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

}
