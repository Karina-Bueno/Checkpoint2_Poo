public class Residente extends Usuario {

    private String cpf;

    public Residente(){};

    public Residente(int id, String nome, String email, String telefone, String cpf, String whatsapp) {
        super(id, nome, email, telefone);
        this.cpf = cpf;
    }

    public String getCpf() {
        return cpf;
    }

    public void setCpf(String cpf) {
        this.cpf = cpf;
    }
    
}
