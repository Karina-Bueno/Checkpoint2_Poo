import java.util.InputMismatchException;
import java.util.Scanner;

public class Checkpoint {
    public static void main(String[] args) {
        Empresa empresa = new Empresa("123456789");
        UsuarioFactory usuario = UsuarioFactory.getInstance();
        MaterialFactory material = MaterialFactory.getInstance();
        int x = 1;
        int resposta = 0;
        int numero = 1;
        Scanner leia = new Scanner (System.in);

         String  nome;
         String  email;
         String telefone;


        while (x != 0) {
            try {
                resposta = mostraMenu();

                while (resposta != 1 && resposta != 2 && resposta != 3) {
                    System.out.println("Digite [1], [2] ou [3] ");
                    resposta = leia.nextInt();

                }
                if (resposta == 1){
                    Scanner user = new Scanner(System.in);
                    System.out.print("Nome: ");
                    user.next();
                    System.out.print("Telefone: ");
                    user.next();
                    System.out.print("Email: ");
                    user.next();
                    System.out.print("cnpj: ");
                    user.next();
                    empresa.addUsuario(usuario.criarUsuario("O",numero,));
                    System.out.println("");
                };
            } catch (ArithmeticException erro) {
                System.out.println(" Desculpe, n�o entendemos o que voc� quis dizer, tente novamente\n");
            } catch (InputMismatchException erro) {
                System.out.println ( " Desculpe, n�o entendemos o que voc� quis dizer, tente novamente\n");
            } catch (Exception erro) {
                System.out.println( " Desculpe, n�o entendemos o que voc� quis dizer, tente novamente\n");
            }
        }
    }
    public static int mostraMenu(){
        Scanner leia = new Scanner (System.in);
        System.out.println("escolha uma das opções abaixo:");
        System.out.println("\n Digite [1]- cadastrar organização de recicláveis");
        System.out.println("\n Digite [2]- cadastrar colaborador de reciclaveis");
        System.out.println("\n Digite [3]- cadastrar usuário");
        System.out.println("\n Digite [4]- cadastrar agendamento");
        return Integer.parseInt(leia.nextLine());}
}
