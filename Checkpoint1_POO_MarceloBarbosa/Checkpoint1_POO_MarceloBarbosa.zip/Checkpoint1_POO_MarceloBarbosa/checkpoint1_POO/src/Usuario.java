public class Usuario {
    protected int id;
    protected String  nome;
    protected String  email;
    protected String telefone;
    private Endereco endereco;



    public Usuario(int id, String nome, String email, String telefone) {
        this.id = id;
        this.nome = nome;
        this.email = email;
        this.telefone = telefone;
    }

    public Usuario(){};

    public void cadastrarEndereco(String logradouro, String referencia, String bairro, int cep){
        this.endereco = new Endereco(logradouro, referencia, bairro, cep);
    }

    public void imprimirEndereco(){
        this.endereco.imprimirEndereco();
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getTelefone() {
        return telefone;
    }

    public void setTelefone(String telefone) {
        this.telefone = telefone;
    }
}
