import java.util.ArrayList;

public class Empresa {
    private String cnpj;
    //criar usuarios
    private ArrayList<Usuario> listausuaario = new ArrayList<>();

    public Empresa(String cnpj) {
        this.cnpj = cnpj;
    }
    //adicionar usuario
    public void addUsuario(Usuario usuario){
        listausuaario.add(usuario);
    }

    public String getCnpj() {
        return cnpj;
    }

    public void setCnpj(String cnpj) {
        this.cnpj = cnpj;
    }

    public ArrayList<Usuario> getListausuaario() {
        return listausuaario;
    }

    public void setListausuaario(ArrayList<Usuario> listausuaario) {
        this.listausuaario = listausuaario;
    }
}
