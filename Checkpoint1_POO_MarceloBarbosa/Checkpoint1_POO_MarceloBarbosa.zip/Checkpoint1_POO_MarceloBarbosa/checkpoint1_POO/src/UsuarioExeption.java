public class UsuarioExeption extends Exception{
}
