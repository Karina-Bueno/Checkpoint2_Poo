public interface CobrarTaxa {

    public double calcularValor(double peso, double taxa);
    public double calcularValor(double peso, double taxa, double taxaRisco);
}
